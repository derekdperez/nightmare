﻿# Change Log

## 2026-04-12

- Fixed server-side origin/report fetch issues:
  - `server.py` now adds `Access-Control-Allow-Origin: *` (and related allow headers/methods) on responses plus `OPTIONS` handling.
  - Added output-root static fallback routing for non-API paths so report-relative fetches (for example `/all_domains.results_summary.json`) resolve when `/` serves the all-domains report.
- Why: generated report pages were failing to load companion JSON/log data in browser due origin/fetch path failures.

- Updated `server.py` default serving + configurability:
  - Added server config file `config/server.json` with default `host`, `port`, and `output_root`.
  - Added `--config` support in `server.py`; CLI values still override config.
  - Changed route `/` to serve `all_domains.results_summary.html` by default when available.
  - Added `/dashboard` route for the live monitoring overview UI.
- Why: operators wanted configurable hosting port and immediate landing on the all-domain HTML report.

- Added live dashboard web server (`server.py`) for runtime visibility and report serving:
  - New stdlib threaded HTTP server with auto-refresh dashboard at `/`.
  - Exposes `/api/summary` JSON containing aggregate + per-domain status from output artifacts.
  - Serves generated reports/artifacts via `/files/<repo-relative-path>` with path-safety checks.
  - Dashboard links to Nightmare/Fozzy reports and shows per-domain latest log tail snippets.
- Why: provide a single place to watch ongoing activity and open generated HTML reports while scans/fuzzing are running.

- Added extractor domain-target + worker-config support:
  - `extractor.py` now accepts optional positional `domain` to run extractors for a specific domain output tree.
  - Added parallel processing with configurable worker count (`--workers`), including config-driven default.
  - Added extractor config file loading via `--config` with new default config file `config/extractor.json`.
  - New `config/extractor.json` includes `"workers": 4` default.
- Why: allow focused extractor runs by domain and improve throughput across domains with configurable concurrency.

- Improved post-fuzz finalization behavior in `fozzy.py` to prevent apparent hangs:
  - Added explicit progress lines for finalization stages (artifact write, per-domain summary, master summary generation).
  - Removed temporary `SIGINT` ignore during finalization so `Ctrl+C` remains responsive.
  - Added interrupt handling around master summary generation to skip that step and finish with partial outputs if user interrupts.
- Why: runs could appear stalled after group-level "execution finished" logs, and interrupts were not honored during finalization.

- Added configurable page-existence criteria for Nightmare:
  - New config file: `config/page_existence_criteria_config.json`.
  - `config/nightmare.json` now includes `page_existence_criteria_config` to select criteria file.
  - `nightmare.py` now loads/sanitizes this criteria and applies it in soft-404 detection and not-found status handling.
  - Effective output filtering (`*_url_inventory.json` entries and related downstream artifacts) now excludes URLs with configured not-found status codes, not only soft-404 markers.
- Why: pages like `/.htpasswd` or `/add` may return small branded 200 "Page Not Found" responses and should be treated as non-existent using configurable detection logic.

- Improved Fozzy Ctrl+C shutdown semantics:
  - `run_incremental_domains()` now returns interruption status.
  - `main()` now exits with code `130` after graceful cleanup when interrupted in either incremental or single-domain run paths.
- Why: interrupts were often handled internally with partial-output finalization but process exit status still appeared successful (`0`), which made cancellation handling less predictable.

- Fixed Fozzy single-domain report loading when opened as local files:
  - `render_anomaly_summary_html()` now embeds a single-domain fallback payload directly in the generated HTML.
  - Browser JS now skips fetch/XHR disk reads when the page protocol is `file:` and uses embedded payload data for table bootstrap.
- Why: modern browsers block `file://` fetch/XMLHttpRequest with CORS-origin `null`, which previously caused empty report tables and console errors.

- Added crawl request inventory output to `nightmare.py`:
  - New per-domain artifact: `output/<root-domain>/requests.json` (config key `requests_output`, CLI override `--requests-output`).
  - Includes every crawl-requested URL with booleans for `found_directly`, `guessed`, `inferred`, and `exists`, plus supporting status/source fields.
  - Added `crawl_requested` to URL inventory records so crawl-attempted URLs (including failures) are tracked explicitly and serialized in session state.
  - Added help text key `requests_output_help` in `config/nightmare.help.json`.
- Why: spidering runs now emit a dedicated machine-readable request ledger with discovery classification and existence signal as requested.

- Added `requirements.txt` at repo root for pip installs with core runtime dependencies:
  - `openai`
  - `scrapy`
  - `tldextract`
- Why: provide a standard `pip install -r requirements.txt` setup path.

- Updated `pack.py` / `unpack.py` transport format:
  - `pack.py` now writes a base64-JSON transport envelope (`transport_encoding: base64-json`) so the packed text payload itself is encoded for transport.
  - `unpack.py` now decodes that envelope before restoring files, with backward compatibility for older raw packed JSON format.
- Why: explicit transport-safe encoding was requested in addition to per-file base64 content storage.

- Added repository pack/unpack utilities:
  - New `pack.py`: creates a single `packed.json` containing directory paths, file paths, metadata, and base64 file contents.
  - New `unpack.py`: restores files/folders from `packed.json` with path traversal safety checks.
  - `pack.py` excludes the `output/` directory tree and skips the output `packed.json` file itself.
- Why: provide deterministic project snapshot/restore workflow without relying on external archive formats.

- Optimized `fozzy.py --generate-master-report` HTML generation to avoid large inline table payloads:
  - Removed server-side row inlining for `master_domain_inventory`, `master_per_route_inventory`, and `extractor_matches`.
  - Master report now emits lightweight table shells and populates those sections client-side from loaded summary JSON.
- Why: reduce master-report generation stalls and keep HTML output lightweight and data-driven.

- Added persistent process logging for `fozzy.py` and `extractor.py`:
  - `fozzy.py` now supports config/CLI `log_file` and defaults to mode-specific logs:
    - single-domain run: `<domain-output>/<root_domain>.fozzy.log`
    - incremental run: `<scan-root>/fozzy.incremental.log`
    - master-report generation: `<master-root>/fozzy.master_report.log`
  - `extractor.py` now defaults to `<scan-root>/extractor.log` and supports `--log-file`.
- Why: operators need durable logs instead of console-only output.
- Added master-report log viewer in `all_domains.results_summary.html`:
  - Master payload now includes discovered `log_files`.
  - HTML includes a log selector + viewer that loads selected logs from disk at runtime.
- Why: allow quick troubleshooting without leaving the master report.

- Refactored `fozzy.py` results HTML rendering to avoid inlining large discrepancy datasets:
  - `render_anomaly_summary_html()` now emits a lightweight shell and loads discrepancy rows from the companion `*.results_summary.json` file at page load.
  - Added `summary_json_filename` to summary payloads in both single-domain and master summary writers.
  - Added browser-side fallback messaging when local-file fetch/XHR of JSON is blocked by browser security.
- Why: report table data should be sourced from on-disk files at load time rather than hardcoded into generated HTML.

- Added dedicated incremental domain concurrency control in `fozzy.py`:
  - New config key: `incremental_domain_workers` (added to `config/fozzy.json`).
  - New CLI override: `--incremental-domain-workers`.
  - `run_incremental_domains()` now uses `incremental_domain_workers` instead of reusing `max_background_workers`.
- Why: separate multi-domain scheduling from per-domain fuzz worker settings so both can be tuned independently.
- Updated master HTML extractor section rendering:
  - Extractor table now renders even when there are zero extractor rows.
  - Importance column label/filter updated to explicit `Importance score`.
- Why: ensure generated HTML consistently includes the importance-score column/schema for downstream review and automation.

- Fixed `fozzy.py` incremental multi-domain execution to honor configured worker concurrency:
  - `run_incremental_domains()` now runs domains in parallel via child-process workers instead of a serial `for` loop.
  - Worker count comes from effective `max_background_workers` (including config/CLI overrides).
  - Added failure reporting per domain and graceful interrupt handling for active child workers.
- Why: with no parameters file, Fozzy previously processed one domain at a time regardless of `max_background_workers`.
- Incremental mode now launches each domain run with per-domain worker caps forced to `1` (`--max-background-workers 1`, etc.) while the parent controls overall domain concurrency.
- Why: prevent N x M thread explosion and shared in-process global-config races when running multiple domains concurrently.

- Updated `nightmare.py` spider wordlist seeding to support both default and custom wordlists:
  - Added `--crawl-wordlist` CLI option and `crawl_wordlist` config key.
  - Added `resolve_wordlist_path()` resolution rules (repo-relative + bare filename fallback to `resources/wordlists/`).
  - Generalized seed loading to read from a selected wordlist path and accept absolute URL entries as well as relative paths.
- Why: spidering needed to include all configured path seeds, not just a hardcoded file.
- Updated crawl budget behavior for path-seed runs:
  - `crawl_domain()` now increases effective crawl page budget when needed so all pending seed URLs (including wordlist seeds) are schedulable in the run.
  - Wordlist seeds are now registered in discovery inventory with source `file_path_wordlist`.
  - `guessed_paths_index.json` now records the actual wordlist source used in that run.
- Why: previous `max_pages` caps could silently drop many wordlist seed paths from spider execution and reporting.

- Updated `fozzy.py` incremental scan behavior to reduce "appears hung" startup:
  - Replaced `Path.rglob`-based mtime traversal with `os.scandir` iterative traversal in `folder_tree_max_mtime_ns` for lower overhead on large trees.
  - Added immediate per-domain progress output during incremental dirty-check pass in `run_incremental_domains`.
- Why: default no-argument execution could spend a long time in pre-run change detection with no visible output.
- Hardened `nightmare.py` batch state persistence against transient Windows file-lock failures:
  - `_atomic_write_json` now uses a unique temp filename and retries atomic replace with short backoff before failing.
  - Batch `persist()` now catches write errors and logs a warning instead of terminating the orchestrator.
- Why: observed crash on `[WinError 5] Access is denied` when rotating `batch_run_state.json` during batch completion.
- Added extractor `importance_score` support to reporting pipeline:
  - `extractor.py` now carries `importance_score` from `resources/wordlists/extractor_list.txt` into both match detail files and `extractor/summary.json` rows.
  - Master HTML report table in `fozzy.py` now includes an `Importance` numeric column with sortable header and per-column filter input.
- Why: extractor list now includes score metadata and report needs analyst triage by severity/priority.

- Fixed `fozzy.py` master-report HTML template f-string syntax for Python runtime compatibility:
  - Moved backslash-bearing JSON escaping (`.replace("</", "<\\/")`) out of inline f-string expressions and into precomputed variables.
  - Template now interpolates `summary_json_filename_js` and `master_log_files_js` constants.
- Why: Python raised `SyntaxError: f-string expression part cannot include a backslash` at startup on `python3 fozzy.py`.

- Fixed `UnboundLocalError` in `render_anomaly_summary_html` when generating single-domain summaries:
  - Initialized `master_log_files = payload.get("log_files")` before building JSON-escaped JS constants.
  - Removed later duplicate assignment and reused the initialized variable for master-only log viewer section checks.
- Why: child domain workers crashed during `write_results_summary()` with `local variable 'master_log_files' referenced before assignment`, causing incremental domain failures.

- Added `--status` quick-report mode to `nightmare.py`:
  - New CLI flag `--status` prints aggregate progress without running crawl/batch work.
  - Report fields include spidered target-domain coverage, total unique requested URLs, total unique parameterized GET routes, and top 10 domains by URL volume.
  - Per-domain top-list rows include: unique URLs, parameterized GET count, extractor matches, anomalies, and reflections.
  - Metrics are loaded from on-disk artifacts (`*_url_inventory.json`, `*.parameters.json`, `fozzy.summary.json`, `extractor/summary.json`) with safe fallbacks.
- Why: provide a fast operational snapshot of campaign progress directly from existing output files.

- Added soft-404 filtering for HTTP 200 pages in `nightmare.py` so non-existent pages are not treated as successful:
  - New response heuristics detect likely soft-404 pages using title markers and common not-found phrases on small 200 responses.
  - `probe_url_existence()` now validates HEAD 200 with a follow-up GET and marks soft-404 pages as `exists_confirmed=false`.
  - Crawl parser now marks soft-404 responses and skips link extraction for those pages.
  - URL inventory/source-of-truth output now excludes soft-404 records from effective `entries`/`total_urls` while preserving raw data in `entries_raw` and `total_urls_raw`.
  - Wordlist guessed-path hit logic now treats soft-404 responses as misses.
- Why: 200 status alone is not a reliable existence signal; generic “page not found” templates were inflating discovered/existing counts.

## 2026-04-13

- Fixed all-domains report load reliability in `fozzy.py`:
  - Added compact master-discrepancy serialization (`compact_discrepancies=True`) that trims `baseline/anomaly body_preview` and long unified diff text before writing `all_domains.results_summary.json`.
  - Added explicit master-table fallback rendering when summary payload cannot be loaded, so inventory/extractor tables show a concrete error message instead of staying on `Loading...` indefinitely.
- Why: master summary JSON can grow too large for reliable browser fetch/parse/render, and payload-load failures previously left multiple master tables in a perpetual loading state.

- Hardened report writes against corruption:
  - Added `_atomic_write_text(...)` and switched master/single-domain summary JSON+HTML writes to atomic temp-file replacement.
- Why: interrupted or failed writes (for example, low disk conditions) should not leave zero-byte summary artifacts that break report loading.

- Improved worker scheduling and profiling in `nightmare.py` for high-concurrency runs:
  - Batch workers now receive OS-specific priority hints.
    - Windows: each worker process gets a reduced CPU affinity mask (default: subset of available cores; configurable via `batch_worker_affinity_cores`).
    - macOS/Linux: each worker process applies `os.nice(+10)` by default (configurable via `batch_worker_nice`).
  - Added dev-only timing instrumentation with per-method aggregates and slowest-call output (`[dev-perf]`) for key pipeline methods (crawl, AI calls, probe calls, artifact writes, batch orchestration stages).
  - Added config keys: `environment`, `dev_timing_logging`, `dev_timing_log_each_call`, `batch_worker_nice`, `batch_worker_affinity_cores`.
- Why: lower worker scheduling priority prevents worker saturation from starving interactive/system workloads, and dev-only timing data makes performance hotspots visible for targeted optimization.

- Added self-hosted coordinator foundation in `server.py` with optional Postgres backend (`database_url`):
  - New `/api/coord/*` endpoints for target registration, claim/heartbeat/complete, session save/load, and coordinator state summaries.
  - Added token-based protection (`coordinator_api_token`) for coordinator endpoints.
- Added web-server style dual listeners in `server.py`:
  - Supports HTTP and HTTPS listeners simultaneously via `http_port` and `https_port` (defaults now `80` and `443`).
  - HTTPS listener requires `cert_file` + `key_file`; if absent, HTTPS is disabled with explicit startup warning.
  - Retains backward compatibility with legacy `--port` single-listener mode.
- Added dependency `psycopg[binary]` in `requirements.txt` for Postgres coordinator mode.
- Why: support a central self-hosted coordination server that behaves like a standard web server while persisting shared queue/session state in Postgres for multi-VM execution.

- Implemented centralized distributed orchestration stack for multi-VM scaling:
  - `server.py` now includes Postgres-backed coordinator APIs for target leaseing, stage leaseing, session checkpointing, and artifact storage/replication.
  - Added tables: `coordinator_targets`, `coordinator_sessions`, `coordinator_stage_tasks`, `coordinator_artifacts`.
  - Added endpoints:
    - target queue: `/api/coord/register-targets`, `/api/coord/claim`, `/api/coord/heartbeat`, `/api/coord/complete`
    - stage queue: `/api/coord/stage/enqueue`, `/api/coord/stage/claim`, `/api/coord/stage/heartbeat`, `/api/coord/stage/complete`
    - session/artifacts: `/api/coord/session` (GET/POST), `/api/coord/artifact` (GET/POST), `/api/coord/artifacts`.
- Added `coordinator.py` distributed worker orchestrator:
  - Runs Nightmare/Fozzy/Extractor concurrently with dedicated worker pools (default 2 each).
  - Uses lease heartbeat for target and stage locks.
  - Uploads session checkpoints during active crawl and syncs artifacts to Postgres for cross-VM continuation.
  - Enqueues stage transitions (`nightmare -> fozzy -> extractor`) only after successful completion.
- Added full container/deploy scaffolding for EC2:
  - `Dockerfile`, `docker-entrypoint.sh`, `.dockerignore`
  - `deploy/docker-compose.central.yml` (server + postgres)
  - `deploy/docker-compose.worker.yml` (distributed workers)
  - `deploy/.env.example`, `deploy/bootstrap-central.sh`, `deploy/bootstrap-worker.sh`
  - `DEPLOYMENT.md` with operational runbook.
- Updated dependencies with `psycopg[binary]` for Postgres support.
- Why: enable horizontal VM scale-out with centralized locking/state, resumable failover, and shared artifact/session access across workers.

- Restored/strengthened Cloudflare block detection in `nightmare.py` soft-404 logic:
  - Added explicit Cloudflare invalid-page rule requiring BOTH title phrase (`attention required! | cloudflare`) and blocked-body phrase (`sorry, you have been blocked`).
  - Rule is evaluated before status-specific soft-404 heuristics, so blocked pages with non-200 statuses are still classified non-existent/invalid.
  - `probe_url_existence()` HTTPError path now also runs `detect_soft_not_found_response()` and marks `exists_confirmed=false` when blocked markers are present.
- Updated page existence criteria schema/config with `cloudflare_block_title_phrase` and `cloudflare_block_body_phrase` keys.
- Why: Cloudflare challenge/block pages were being miscounted as existing due to missing checks in HTTPError flow and overwritten title/body marker handling.

## 2026-04-13

- Added automated central bootstrap script: deploy/bootstrap-central-auto.sh.
  - Generates strong random POSTGRES_PASSWORD + COORDINATOR_API_TOKEN.
  - Auto-detects base URL from EC2 metadata (public hostname/IP) with fallback to external IP/hostname.
  - Generates self-signed TLS cert/key under deploy/tls/.
  - Writes deploy/.env and deploy/worker.env.generated.
  - Rebuilds and starts the central Docker stack in one command.
- Why: enable immediate multi-VM bring-up with secure defaults and minimal manual setup steps.

- Updated image/compose secret injection:
  - Dockerfile now accepts build args for COORDINATOR_BASE_URL, COORDINATOR_API_TOKEN, and DATABASE_URL and exports them as image env vars.
  - deploy/docker-compose.central.yml and deploy/docker-compose.worker.yml now pass those build args during image build.
- Why: allow rebuilt images to carry the generated coordinator connection/security values when requested.

- Added Windows-native deployment bootstrap script: deploy/bootstrap-windows.ps1.
  - Supports -Role Central and -Role Worker setup flows.
  - Central flow generates strong credentials, detects coordinator base URL, creates TLS PEM cert/key, writes deploy/.env and deploy/worker.env.generated, and starts central compose stack.
  - Worker flow writes worker .env from passed args (or copied worker.env.generated) and starts worker compose stack.
- Why: enable end-to-end setup on Windows VMs without Bash/WSL.
- Fixed deploy/bootstrap-windows.ps1 script-path resolution bug on Windows PowerShell where $MyInvocation.MyCommand.Path inside function scope can be absent.
- Updated path bootstrap to use $PSScriptRoot with $PSCommandPath fallback.
- Why: script crashed at startup with "property 'Path' cannot be found".
- Enhanced deploy/bootstrap-central-auto.sh for Linux bootstrap reliability:
  - auto-installs missing dependencies on apt-based hosts (docker, docker compose plugin, curl, openssl, git) and enables docker service.
  - adds optional one-command worker auto-provisioning flow (--auto-provision-workers) integrated with new AWS helper script.
- Added deploy/provision-workers-aws.sh to launch and cloud-init bootstrap worker EC2 instances directly from central.
- Added .gitattributes rules to force LF endings for shell scripts and deployment YAML to prevent cross-platform shebang/parse failures.
- Updated Linux bootstrap package-manager support to prefer yum/dnf with pt-get fallback.
  - deploy/bootstrap-central-auto.sh now installs dependencies via yum/dnf first and validates docker compose availability.
  - deploy/provision-workers-aws.sh cloud-init now installs packages via yum/dnf/apt detection instead of apt-only package list.
- Why: support Amazon Linux/RHEL-style EC2 hosts where pt-get is unavailable.
- Hardened bootstrap against Docker Compose version mismatches:
  - deploy/bootstrap-central-auto.sh now resolves compose CLI as docker compose or docker-compose fallback.
  - deploy/provision-workers-aws.sh cloud-init now uses the same fallback before starting worker stack.
- Why: older AMIs often ship standalone docker-compose without compose plugin, causing version/command failures.
- Fixed Amazon Linux 2023 dependency bootstrap conflict (curl vs curl-minimal).
  - deploy/bootstrap-central-auto.sh now installs curl-minimal for yum/dnf hosts.
  - deploy/provision-workers-aws.sh cloud-init also uses curl-minimal on yum/dnf.
- Why: AL2023 ships curl-minimal by default and installing curl caused dependency solver failures.
- Fixed AL2023 compose package availability issue: bootstrap no longer depends on docker-compose-plugin in yum/dnf repos.
  - Central bootstrap now installs standalone docker-compose binary automatically if compose plugin/command is missing.
  - Worker cloud-init uses same fallback.
- Why: many Amazon Linux images do not provide docker-compose-plugin package, which previously caused setup failure.
- Fixed bootstrap failure when Docker is installed but current user lacks socket permissions.
  - deploy/bootstrap-central-auto.sh now detects Docker access mode and falls back to sudo for compose commands automatically.
- Why: Amazon Linux ec2-user often needs re-login after docker group changes; bootstrap should continue in current session.
- Added AWS credential preflight in deploy/provision-workers-aws.sh using ws sts get-caller-identity with actionable remediation guidance.
- Why: central setup could succeed, then worker provisioning failed late with opaque "Unable to locate credentials".
- deploy/provision-workers-aws.sh now auto-loads coordinator URL/token from deploy/.env when flags are omitted.
- Why: operators should not need to manually look up or pass coordinator credentials after central bootstrap.
- Fixed master HTML extractor section reliability by bounding extractor rows included in ll_domains.results_summary.json.
  - ozzy.py now caps master payload extractor rows at MASTER_REPORT_EXTRACTOR_ROWS_MAX (10,000), while tracking extractor_matches_total and extractor_matches_truncated.
  - Master report UI now shows explicit truncation note when full extractor dataset is larger than rendered payload.
- Why: very large per-domain extractor summaries could make master summary payload too large to load/render, causing extractor table to appear stuck/empty.

- Added central worker fleet status endpoint to coordinator server:
  - `server.py` now exposes `GET /api/coord/workers` (token-protected like other `/api/coord/*` endpoints).
  - Endpoint aggregates `coordinator_targets` and `coordinator_stage_tasks` by `worker_id`, returning:
    - worker heartbeat recency (`last_heartbeat_at_utc`, `seconds_since_heartbeat`)
    - online/stale classification using configurable `stale_after_seconds`
    - running/active lease counts and active stage names.
- Why: operators needed a single API to verify all worker VM process identities and health from the central machine.

- Added `client.py` operator CLI for one-command status checks from central:
  - `python client.py status` now performs:
    - coordinator worker status query (`/api/coord/workers`)
    - optional AWS SSM fanout command to each worker VM to report `docker compose ... worker ... ps` container state.
  - Supports environment-first configuration from `deploy/.env` and flags for region/target override (`--aws-region`, `--ssm-target-*`) plus `--skip-ssm`.
- Why: remove repetitive manual AWS/SSM/curl command sequences and provide a fast, consistent operational status check entrypoint.

- Added centralized worker rollout command in `client.py`:
  - New action: `python client.py rollout`.
  - Uses AWS SSM fanout to run on each targeted worker VM:
    - `git fetch --all --prune`
    - `git checkout <branch>`
    - `git pull --ff-only origin <branch>`
    - `docker compose ... up -d --build` for worker stack restart
    - `docker compose ... ps --format json` for post-restart status output.
  - Added rollout flags: `--branch`, `--repo-dir`, `--ssm-target-key`, `--ssm-target-values`.
- Why: operators needed a single central command to update worker VM code and restart processing across the fleet.

- Fixed coordinator worker crash loop on startup (`NameError: CoordinatorConfig`).
  - Moved the shared `CoordinatorConfig` dataclass into `coordinator_app/runtime.py` and imported it in `coordinator.py` so `load_config()` can instantiate it in-module.
  - Restored missing runtime helpers `_read_json_dict` and `_now_iso` used by `SessionUploader`.
- Why: workers were exiting immediately during config load; this unblocks normal boot and prevents the next latent NameError in session upload path.

- Fixed local deploy auth mismatch caused by regenerated secrets with persisted Docker volumes.
  - Updated `deploy/run-local.ps1` and `deploy/run-local.sh` to reuse existing `POSTGRES_PASSWORD` and `COORDINATOR_API_TOKEN` from `deploy/.env` when present.
- Why: repeated local runs were regenerating DB credentials while keeping `postgres_data`, causing server startup failure (`password authentication failed`) and downstream worker `connection refused` loops.

- Fixed local worker TLS failure against self-signed coordinator cert (`CERTIFICATE_VERIFY_FAILED`).
  - Added coordinator `insecure_tls` setting to runtime config model and loader (`COORDINATOR_INSECURE_TLS` env-supported).
  - Updated local/worker compose env wiring and local bootstrap scripts so local runs set `COORDINATOR_INSECURE_TLS=true`.
  - Kept `config/coordinator.json` free of hardcoded `insecure_tls` so deployment-specific env values can control TLS behavior.
- Why: local Docker workers connect to `https://server:443` with a self-signed certificate; strict verify caused perpetual claim failures while server itself was healthy.

- Expanded project-wide unit test coverage with deterministic, fast tests and no external service dependencies.
  - Added `tests/conftest.py` to ensure repo-root imports work under both `pytest` and `python -m pytest`.
  - Added new unit test modules for:
    - shared config utilities and model validation,
    - HTTP client behavior (success, HTTP errors, network failures, capped reads),
    - coordinator runtime helpers (`SessionUploader`, zip/unzip safety, subprocess logging, config loading),
    - HTTP request queue lifecycle (enqueue/claim/retry/dead-letter/success),
    - pack/unpack archive utilities,
    - operator/client + queue CLI helpers + target registration helpers,
    - report rendering and pure helper functions in `server_app/store.py`.
- Why: raise confidence for refactors and runtime bug fixes while keeping CI/local test runs short and infrastructure-independent.

- Hardened central server runtime against public internet scanner disconnect noise.
  - Added `_is_client_disconnect_error(...)` and handler-level suppression for common connection-abort/TLS disconnect exceptions in `server.py` so expected scanner aborts no longer emit full stack traces.
  - Removed obsolete Compose `version` key from `deploy/docker-compose.central.yml` and `deploy/docker-compose.worker.yml` to remove deprecation warning noise.
  - Added unit tests for disconnect classification helper.
- Why: AWS-exposed central nodes were producing noisy traceback logs (`BrokenPipeError`) from malformed/scanner traffic despite healthy service behavior.

## 2026-04-16

- Refactored `server.py` to remove embedded coordinator data-access implementation (`CoordinatorStore`) and import it from `server_app/store.py`.
  - Added `CoordinatorStore.database_status()` to `server_app/store.py` so the `/api/coord/database-status` API remains functional after extraction.
  - Removed duplicate target-normalization/store helpers from `server.py` that only existed to support the in-file store class.
  - Switched dashboard/worker page rendering to template helpers in `reporting/server_pages.py` and removed large inline page-render methods from `server.py`.
  - Added regression coverage in `tests/test_module_decomposition.py` to assert `server.py` uses external store module and no longer defines `class CoordinatorStore`.
- Why: `server.py` had become a large mixed-responsibility file; this extraction enforces module boundaries and reduces maintenance risk for future decomposition work.

- Fixed AWS worker bootstrap/provision TLS wiring for self-signed coordinator certificates:
  - `deploy/bootstrap-central-auto.sh` now persists `COORDINATOR_INSECURE_TLS` into both `deploy/.env` and `deploy/worker.env.generated` (defaulting to `true` for the self-signed bootstrap flow).
  - `deploy/provision-workers-aws.sh` now accepts/loads `COORDINATOR_INSECURE_TLS` and writes it into each worker `deploy/.env` during cloud-init.
- Why: workers could stay idle with pending targets because coordinator claims failed on certificate verification against bootstrap-generated self-signed certs.

- Restored database page discoverability in server UI after template refactor:
  - Added `/database` navigation links back into `templates/server_dashboard.html.j2` and `templates/worker_control.html.j2`.
  - Added template regression tests in `tests/test_refactor_modules.py` to assert database link presence in rendered dashboard/worker pages.
- Why: `/database` route still existed but link/navigation disappeared from the website UI after page-render modularization.

- Converted `/database` to shared template rendering flow:
  - Added `templates/database_status.html.j2`.
  - Added `render_database_html()` in `reporting/server_pages.py`.
  - Updated `server.py` `/database` route to use template renderer and removed inline `_render_database_html`.
- Hardened dashboard/worker UI runtime behavior:
  - Replaced `replaceAll("%2F", "/")` with `replace(/%2F/g, "/")` for broader JS compatibility.
  - Added visible dashboard load-error handling (`showLoadError`) instead of silent refresh failure.
  - Fixed malformed JS in worker logs link rendering that prevented template script execution.
- Extended refactor tests:
  - Added assertions for database template rendering and route wiring expectations.
  - Updated decomposition tests to enforce externalized database page rendering in `server.py`.

- Limited coordinator database-status payload size for stability:
  - server_app/store.py now returns only the first 20 rows per table (max_rows_per_table=20) while still returning full ow_count via COUNT(*).
  - Added ows_returned and ows_limited metadata per table.
  - Updated 	emplates/database_status.html.j2 to display truncation context (showing first N rows) and show the active row-limit card.
  - Added unit coverage in 	ests/test_reporting_and_store_helpers.py to lock row-limit/query behavior.

- Added coordinator token cookie persistence in server UI templates:
  - 	emplates/database_status.html.j2 now reads/writes 
ightmare_coord_token and auto-populates token input on load.
  - 	emplates/worker_control.html.j2 now uses the same cookie behavior for shared auth UX across coordinator pages.
  - Cookie attributes: Path=/, SameSite=Strict, Max-Age (30 days), and Secure when served over HTTPS.
  - Added template regression assertions in 	ests/test_refactor_modules.py for cookie helper presence.

- Hardened /api/coord/database-status to prevent UI hangs on large tables/artifacts:
  - Switched per-table row count from expensive COUNT(*) scans to Postgres catalog estimate (pg_class.reltuples).
  - Kept row cap at 20 and replaced raw SELECT * payloads with preview-safe projections (no full ytea transfer; text/json fields truncated for display).
  - Added response metadata (ow_count_is_estimate, max_text_preview_chars) and UI label for estimated row counts.
  - Updated DB-status unit test fixture to assert new query/model behavior.

- Modularized spider URL policy and fuzzing core logic into reusable modules while preserving existing public function names in main scripts:
  - Added 
ightmare_shared/value_types.py with shared value-type inference (infer_observed_value_type) used by both Nightmare and Fozzy.
  - Added 
ightmare_app/spider_url_policy.py for URL normalization, crawl/AI/source-of-truth filtering, suffix matching, and AI URL condensation helpers.
  - Added ozzy_app/fuzz_core.py for ParameterMeta/RouteGroup models and request-construction helpers.
  - Updated 
ightmare.py and ozzy.py to delegate to these modules via compatibility wrappers, reducing god-file surface without changing call sites.
  - Added module-level regression tests in 	ests/test_modular_spider_fuzz_core.py.
- Fixed coordinator API auth fallback for browser UI pages:
  - `server.py` now accepts `nightmare_coord_token` from `Cookie` header in `_is_coordinator_authorized()` in addition to `Authorization: Bearer` and `X-Coordinator-Token`.
  - Added `_read_cookie()` helper for robust cookie parsing and URL-decoding.
  - Added `tests/test_server_auth_cookie.py` covering bearer, X-token, cookie token, URL-encoded cookie token, and rejection cases.
- Why: operators reported `/database` returning 401 despite valid token usage; cookie fallback hardens auth in environments where auth headers are dropped or not persisted.

- Added normalized crawl export generation into the `nightmare.py` main flow:
  - Integrated `nightmare_app/normalized_exports.write_normalized_exports(...)` after inventory generation.
  - New default artifacts under each domain output now include:
    - `sitemap.json`, `sitemap.xml`, `sitemap.html`
    - `requests.json`, `cookies.json`, `scripts.json`, `high-value.json`, `pages.json`
    - `redirects.json`, `findings.json`
    - mirrored folders: `cookies/`, `scripts/`, `high-value/`, `pages/`
    - `normalized_data/raw_requests/` and `normalized_data/raw_responses/`
  - Fixed normalized export bugs:
    - removed self-copy loop for `pages/` mirroring
    - deduplicated redirect rows and normalized findings rows
    - made high-value source path explicit (`source_high_value_root`) instead of hardcoded wrong root
  - Added `tests/test_normalized_exports_unit.py` to verify `redirects.json` and `findings.json` generation and expected finding types.

- Hardened `/api/coord/database-status` reliability for operator UI:
  - Added server-side exception guard in `server.py` around `CoordinatorStore.database_status()` to return structured HTTP 500 JSON instead of connection resets.
  - Updated `server_app/store.py` `database_status()` to tolerate per-table query failures (records `table_error` for that table and continues).
  - Updated `templates/database_status.html.j2` to render per-table query errors in the page.
  - Added regression test `test_database_status_tolerates_single_table_query_failure` in `tests/test_reporting_and_store_helpers.py`.
- Why: browser-side `Failed to fetch` on the Database page can result from unhandled DB introspection errors; endpoint now degrades gracefully and exposes actionable error details.

- Fixed worker visibility on `/workers` when workers are alive but idle:
  - Added `coordinator_worker_presence` table in `server_app/store.py` schema.
  - Added presence heartbeats (`_touch_worker_presence`) on target/stage claim, heartbeat, and completion paths.
  - Updated `worker_statuses()` and `worker_control_snapshot()` SQL to union worker IDs from target/stage aggregates, queued commands, and worker presence.
  - Added API exception guards in `server.py` for `/api/coord/workers` and `/api/coord/worker-control` to return structured JSON errors instead of connection-reset style failures.
  - Added tests:
    - `test_worker_control_snapshot_includes_presence_only_worker`
    - `test_worker_statuses_includes_presence_only_worker`
- Why: previous worker pages only discovered workers that had target/stage rows or queued commands, so idle polling workers could appear as “no workers discovered”.
- Added coordinator crawl-progress observability path for per-domain crawl monitoring:
  - New store query: `CoordinatorStore.crawl_progress_snapshot(limit=...)` in `server_app/store.py`.
  - New API route: `GET /api/coord/crawl-progress` in `server.py`.
  - New client action: `client.py progress` with `--progress-limit`.
  - `status` action now also prints crawl-progress summary.
- Fixed row-column index mapping bug in crawl-progress result parsing that could misread timestamps/counts and fail at runtime.
- Added tests:
  - `test_client_main_progress_rejects_skip_coordinator`
  - `test_client_main_progress_fetches_crawl_progress`
  - `test_crawl_progress_snapshot_reports_domain_counts`
- Validation: `python -m pytest -q` -> 84 passed.
- Added web app crawl progress report page:
  - New route in `server.py`: `GET /crawl-progress`.
  - New template-backed renderer in `reporting/server_pages.py`: `render_crawl_progress_html()`.
  - New template `templates/crawl_progress.html.j2` with token-cookie auth, auto-refresh (3s), domain filter, limit control, and table showing phase/found/visited/frontier/active-workers/activity age from `/api/coord/crawl-progress`.
- Added cross-page navigation link to Crawl Progress from dashboard/workers/database templates.
- Added/updated tests for template render and server decomposition imports.
- Validation: full suite passes (`python -m pytest -q` => 86 passed).
- Fixed coordinator DB-status table preview regression and tightened DB table introspection behavior:
  - Resolved placeholder mismatch bug caused by `format('<bytea %s bytes>', ...)` by switching to SQL string concatenation for bytea preview.
  - Removed `reltuples` row estimate usage; `database_status()` now executes exact `COUNT(*)` per table.
  - Table row preview now returns only top 20 rows (ordered by most recent timestamp/id-style columns when available) and reports truncation against exact count.
- Worker control hardening and stale-worker cleanup:
  - Worker status/control queries now use recency retention windows so historical worker IDs age out of API responses.
  - Added richer worker status derivation (`running`, `paused`, `stopped`, `errored`, `idle`) and hid stale-only records from worker control snapshots.
  - Added worker command lifecycle APIs in store/server (`claim_worker_command`, `complete_worker_command`) and connected distributed coordinator loops to consume `start/pause/stop` commands.
  - Queue behavior now supersedes older queued commands for a worker.
- Dashboard/crawl progress UX:
  - Dashboard `/api/summary` now merges coordinator crawl-progress data, so domains/URL counts still populate even when local output folders are empty on central nodes.
  - Crawl progress defaults increased to 2000 in API/page/client.
- Validation: `python -m pytest -q` -> 88 passed.

- Added extractor artifact exploration surface to the coordinator web app:
  - New page route: `/extractor-matches`.
  - New template: `templates/extractor_matches.html.j2` with domain dropdown (`domain + match count`), search, sortable columns, and file view/download links.
  - New APIs in `server.py`:
    - `GET /api/coord/extractor-matches/domains`
    - `GET /api/coord/extractor-matches`
    - `GET /api/coord/extractor-matches/download`
    - `GET /api/coord/extractor-matches/file`
  - Added in-memory TTL/LRU-style cache for parsed extractor zip content (`_ExtractorMatchesCache`) to avoid repeated unzip/JSON parse overhead.
  - Added store query `CoordinatorStore.list_extractor_match_domains(...)` to list domains with extractor match artifacts and summary-derived counts.
  - Updated cross-page nav links to include Extractor Matches from dashboard/workers/database pages.
  - Added regression coverage for template/module decomposition and extractor-domain listing behavior.
- Validation: `pytest -q` -> 91 passed.

- Extractor Matches page enhancement:
  - Added top-filter summary on `/extractor-matches` showing top 10 filters by match count.
  - `/api/coord/extractor-matches` now returns `top_filters` computed from the full matched set (after optional search filter, before row-limit truncation).
  - UI renders this in a dedicated panel (`Top Filters (Top 10)`).
  - Added unit coverage for ranking/limit behavior (`_top_extractor_filters`).
- Validation: `pytest -q` -> 92 passed.

- Extractor Matches performance/UX hardening:
  - Switched `/api/coord/extractor-matches` to server-side paging/sort/filter with `limit`, `offset`, `sort_key`, `sort_dir`, and per-column `f_<column>` filters.
  - Default page size lowered to 250 (max 2000 per request) to reduce response size and latency.
  - Added response paging metadata (`offset`, `next_offset`, `prev_offset`, `has_more`, applied sort/filter fields).
  - Added fixed-height scrollable table containers on extractor page so large datasets do not expand page height.
  - Added lazy page loading controls (Prev/Next) and debounced server fetches for global and column filters.
  - Added sortable/filterable/searchable behavior for all extractor-page tables:
    - matches (server-driven global + per-column search/filter/sort),
    - top filters (client-side global + column filter + sort),
    - artifact files (client-side global + column filter + sort).
  - Kept top-filter aggregation server-side and based on full filtered set (pre-pagination).
- Validation: `pytest -q` -> 93 passed.

- Added new coordinator web app page: `/fuzzing` (Fozzy findings explorer).
  - New template: `templates/fuzzing.html.j2`.
  - New renderer: `reporting/server_pages.py::render_fuzzing_html`.
  - New route in `server.py`: `GET /fuzzing`.
  - New APIs:
    - `GET /api/coord/fuzzing/domains`
    - `GET /api/coord/fuzzing`
    - `GET /api/coord/fuzzing/download`
    - `GET /api/coord/fuzzing/file`
  - Implemented server-side paging/filter/sort for fuzzing findings (`limit`, `offset`, `sort_key`, `sort_dir`, `f_<column>`, global `q`) with default 250 rows/page and max 2000.
  - Added cache-backed loading/parsing for `fozzy_summary_json` artifacts and zip-file index caching for `fozzy_results_zip` file browsing.
  - Added coordinator store method `CoordinatorStore.list_fozzy_summary_domains(...)` with parsed totals (`anomalies`, `reflections`, requests, groups) and zip availability metadata.
  - Added fixed-height, scrollable tables and search/filter/sort controls in the UI for findings and zipped result files.
  - Added navigation links to Fuzzing from dashboard/workers/database/crawl-progress/extractor pages.
  - Added tests for new renderer, server module wiring, store domain query parsing, and fuzzing row query behavior.
- Validation: `pytest -q` -> 97 passed.

- Extractor domain dropdown improvements:
  - `/api/coord/extractor-matches/domains` now includes `max_importance_score` per domain.
  - Domain ordering now prioritizes highest `max_importance_score` (desc), then `match_count` (desc), then domain name.
  - Added extractor zip stats scan helper to compute both match count and max importance score when summary/cache data is incomplete.
  - Extractor cache entries now persist `max_importance_score` alongside `match_count`.
  - `templates/extractor_matches.html.j2` now includes `hideZeroDomains` checkbox to hide/show zero-result domains in dropdown without reloading artifacts.
  - Dropdown labels now show both highest score and match count per domain.
- Validation: `pytest -q` -> 98 passed.

## 2026-04-17
- Fuzzing page now exposes full baseline vs fuzz comparison columns (request/response content, status/size/duration, and diff columns) from /api/coord/fuzzing rows.
- Added server-side enrichment that reads per-result JSON payloads from ozzy_results_zip and hydrates baseline/fuzz request/response previews + duration metrics for existing artifacts.
- Reflection findings now include reflected text directly in the note field (eflection_detected: <value>) for both live flattening and new fozzy summary outputs.


- 2026-04-17: Fuzzing table UX upgrade: added horizontal scrolling, per-column resize handles, and column hide/show menu with persisted prefs in Postgres via /api/coord/ui-preferences (GET/POST).

- 2026-04-17: Standardized sticky/frozen headers for scrollable web tables (fuzzing, extractor matches, database, workers, crawl progress, dashboard). Added scroll containers to pages that previously had plain tables so header rows stay visible during scrolling.

- 2026-04-17: Expanded Fozzy eflection_alert_ignore_exact defaults and normalization to suppress low-signal reflection values (e.g., 0/1, true/false, null-like/common tokens). Updated config/fozzy.json defaults to match.

- 2026-04-17: Reworked /fuzzing grid to operator layout (URL, Parameter, Payload, Code, Response/Diff actions, Size Diff, Time Diff, Notes placeholder). Added full-screen response modal (stacked headers/body) and side-by-side diff modal with synchronized scrolling and line-level highlighting.
- 2026-04-17: Fixed /api/coord/fuzzing/file lookup for zip members when rows contain basename-only result_file values. Endpoint now resolves by exact path first, then unique basename/suffix fallback to avoid false 'file not found in zip' failures from UI View Response/View Diff actions.

## 2026-04-17
- Implemented a full baseline-driven response analysis subsystem for Fozzy under fozzy_app/response_analysis:
  - normalizer.py (header/body normalization with deterministic volatile-token masking)
  - feature_extractor.py (metadata/header/body + JSON/HTML/XML/text feature extraction)
  - baseline_manager.py (endpoint/template baseline profiles)
  - diff_engine.py (structured semantic diff + similarity + auth/redirect drift)
  - detectors registry (status/header/semantic/stacktrace/error/reflection/structural-drift)
  - scorer.py, summarizer.py, clusterer.py, pipeline.py
- Wired subsystem into fozzy.py fuzz_group live path so every fuzzed response is analyzed and written to <root_domain>.fozzy.response_analysis.jsonl.
- Updated anomaly/reflection artifact payloads to include response_analysis and added analysis fields to summary entries (score, cluster_id, summary).
- Added run summary totals: analyzed_responses and interesting_responses, plus response_analysis_jsonl path in summary JSON.
- Added deterministic unit tests (tests/test_response_analysis_subsystem.py) covering noise suppression, 500+stacktrace, debug header appearance, security header disappearance, JSON->HTML drift, script-context reflection, redirect/login drift, repeated-cluster behavior, SQL errors, Spring Whitelabel detection.
- Validation: pytest -q tests/test_response_analysis_subsystem.py (10 passed); pytest -q tests/test_modular_spider_fuzz_core.py tests/test_reporting_and_store_helpers.py (29 passed).

## 2026-04-17

- Fixed fuzzing response modal header rendering fallback in `templates/fuzzing.html.j2`:
  - Header formatter now supports multiple payload shapes (`response_headers`, `headers`, object/list tuple forms) and only falls back to header-name-only output when values are truly unavailable.
- Why: View Response modal was showing header names without values for many artifact records.

- Enhanced worker control grid in `templates/worker_control.html.j2`:
  - Added persistent worker row selection across auto-refresh/page reload via cookie-backed selected worker IDs.
  - Added global search + per-column filters.
  - Added sortable columns with explicit sort indicators.
  - Selection state now survives data refresh and is reapplied to visible rows.
- Why: operators were repeatedly losing selections on refresh and could not efficiently locate/sort workers in large fleets.

- Standardized table/grid interaction layer across web pages via shared include `templates/_grid_controls.html.j2`:
  - Added reusable column resizing with per-column resize handles.
  - Added double-click auto-fit behavior on resize handles.
  - Added per-table column visibility modal (`Columns`) with persisted hidden/width preferences (DB-backed when available, localStorage fallback).
  - Added optional local sortable/filterable mode used on dashboard/crawl/database data tables.
- Why: make table UX consistent and satisfy operator requirement for resizable/sortable/filterable/configurable grids across pages.

- Fixed fuzzing table resize reliability in `templates/fuzzing.html.j2`:
  - Resize handle now suppresses click propagation (prevents accidental sort-trigger while resizing).
  - Added double-click auto-fit width for the target column.
  - Normalized sort indicator glyphs to ASCII (`^` / `v`) for cross-platform rendering consistency.
- Why: resize drag area was intermittently acting on wrong behavior and did not support requested auto-fit interaction.

## 2026-04-18

- Added two new operator web pages in template-backed server UI:
  - `/docker-status` shows live container status plus compose status snapshots.
  - `/view-logs` lists available docker/file log sources and loads latest 300 lines on demand.
- Added new coordinator-authenticated APIs in `server.py`:
  - `GET /api/coord/docker-status`
  - `GET /api/coord/log-sources`
  - `GET /api/coord/log-tail?source_id=...&lines=...`
- Navigation links across dashboard/worker/database/crawl/extractor/fuzzing pages now include Docker Status + View Logs.
- Added template render helpers in `reporting/server_pages.py` for the two new pages.
- Added/updated tests to cover template render and routing-module expectations for these new pages.
- Why: provide in-app operational visibility for container health and logs without leaving the coordinator web UI.

## 2026-04-18

- Fixed Docker Status / View Logs data scope: APIs now aggregate central server + worker VM data instead of local-host-only lookups.
- Added AWS SSM-backed worker VM collection in `server.py`:
  - worker container discovery via remote `docker compose ... ps --format json`
  - optional remote log-tail collection per container
  - source IDs for remote logs: `ssm:<instance_id>:docker:<container_name>`
- Updated `/api/coord/docker-status` to support `include_logs` and `log_lines` query controls and to return merged container rows (`all_containers`) across central and worker systems.
- Updated `/api/coord/log-sources` and `/api/coord/log-tail` to include and resolve remote worker docker sources.
- Updated Docker Status page UI to render host origin and per-container console output blocks.
- Why: operators needed fleet-wide visibility, not just the coordinator host's local containers/logs.
- Added `awscli` to `Dockerfile` base image packages so server-container fleet status/log APIs can execute SSM queries in central docker-compose deployments.

## 2026-04-18

- Replaced `command_cheatsheet.txt` with a structured "Useful Commands" runbook covering:
  - AWS cluster launch/provisioning
  - central/worker docker-compose deploy and status
  - AWS EC2/SSM worker visibility
  - central/worker docker logs
  - Postgres access and operational SQL checks
  - watch-style monitor commands (placed at end)
- Why: provide one operator-facing reference for day-to-day deployment and troubleshooting workflows.

## 2026-04-18

- Fixed Docker/compose command compatibility in server fleet observability APIs:
  - Compose status probes now try both `docker compose` and `docker-compose` command styles.
- Expanded log-source discovery and collection:
  - Added worker VM docker log sources via AWS SSM.
  - Added AWS EC2 console output sources (`ec2-console:<instance_id>`).
  - Added fallback central docker sources (`nightmare-coordinator-server`, `nightmare-postgres`) when discovery fails.
- Added new log APIs in `server.py`:
  - `GET /api/coord/log-events` (parsed, searchable, filterable, sortable events)
  - `GET /api/coord/log-download` (zip download for selected source)
  - Refactored `GET /api/coord/log-tail` to use unified source readers.
- Upgraded `templates/view_logs.html.j2` into a full log viewer grid with source selector, search/filter/sort controls, and zip download action.
- Upgraded `templates/docker_status.html.j2` to display worker VM count, AWS fleet section, and per-container console output.
- Added optional dedicated structured logging DB support:
  - New `logging_app/store.py` (`LogStore`) with `application_logs` schema and query/insert methods.
  - `server.py` now supports `log_database_url` (config/CLI/env) and writes server request logs to that store when configured.
  - Added config key `log_database_url` in `config/server.json`.
- Deployment updates:
  - `Dockerfile` now installs `docker.io` so containerized server can run docker CLI probes.
  - `deploy/docker-compose.central.yml` now mounts `/var/run/docker.sock` and passes fleet/log env selectors.
  - Added `deploy/docker-compose.log-store.yml` for a dedicated log Postgres stack.
  - Updated `deploy/full_deploy_command.sh` worker default from 6 to 5.
- Why: fix empty log-source experience and provide fleet-wide centralized log visibility with structured query capability and download/export.
## 2026-04-18

- Improved View Logs UX and persistence:
  - Added explicit loading-state indicator with status transitions (`loading`, `success`, `error`, `timeout`).
  - Added request timeouts for source/event fetches so UI can report timeout vs generic failure.
  - Set log-events grid defaults so the message/description columns are widest and easier to read.
  - Enabled persisted column reordering for column-only grids (including View Logs) and saved `column_order` with widths/hidden columns via `/api/coord/ui-preferences`.
- Improved log source performance:
  - Added short TTL cache for collected view-log sources to avoid repeated expensive discovery on every refresh.
  - Added `force_refresh` support to `/api/coord/log-sources`.
  - Reduced worker source discovery stall risk by using a shorter SSM timeout in source discovery path.
  - Replaced broad recursive file-log discovery over entire app root with bounded-depth targeted directories.
- Why: log source loading and layout usability were bottlenecks for operators; this keeps refreshes responsive and makes logs readable without repeated manual table setup.
## 2026-04-18

- Enforced mandatory dedicated logging/reporting DB for server startup.
  - Server now exits with error unless both `database_url` and `log_database_url` are set.
  - Server now exits with error if `log_database_url` appears to point to the same DB as `database_url`.
  - Log store initialization failure is now fatal instead of silently disabling structured logging.
- Updated central compose env contract so `LOG_DATABASE_URL` is required at deploy time.
- Why: user requirement that logging/reporting always run on a separate secondary database VM with no optional/off mode.
## 2026-04-18

- Added dedicated log DB VM provisioning script: `deploy/provision-log-db-aws.sh`.
  - Provisions a single EC2 VM for Postgres log/reporting storage.
  - Bootstraps Postgres in Docker via cloud-init.
  - Writes `LOG_DATABASE_URL` into `deploy/.env`.
  - Rebuilds central server container by default.
- Updated `deploy/bootstrap-central-auto.sh` to enforce and automate dedicated logging DB setup:
  - Reuses existing `LOG_DATABASE_URL` if present.
  - If missing, auto-provisions log DB VM before central compose startup.
  - Fails early when provisioning parameters are missing.
- Added `deploy/deploy-central-with-logdb.sh` as a one-command wrapper for central + worker + log DB provisioning flow.
- Updated `deploy/.env.example` with `LOG_DATABASE_URL` sample and updated `full_deploy_command.sh` default worker count to 5.
- Why: logging/reporting DB is now a mandatory separate VM and should be automatically provisioned in bootstrap workflows.
- Fixed log DB provision script compose target: use compose service name `server` (not container name `nightmare-coordinator-server`) when rebuilding central stack.
## 2026-04-18

- Added worker log bundle download endpoint: `GET /api/coord/worker-log-download?worker_id=<id>`.
  - Auth required.
  - Resolves worker log links and returns zipped log files (`<worker>.worker.logs.zip`).
  - Applies existing max download byte cap when building bundle.
- Updated Workers Control page Logs column:
  - Added `Download Logs` button per worker row.
  - Button opens worker log bundle endpoint and relies on coordinator token cookie auth.
- Why: operators requested one-click worker log download from the worker control center.
## 2026-04-18

- Updated full deploy scripts (`full_deploy_command.sh` and `deploy/full_deploy_command.sh`) to automatically register targets after central bootstrap.
- New behavior:
  - Source `deploy/.env` for coordinator URL/token.
  - Wait for coordinator readiness via `/api/coord/database-status`.
  - Run `python3 register_targets.py --targets-file targets.txt` automatically.
- Why: eliminate post-deploy manual target registration and ensure queue is populated immediately after deployment.
## 2026-04-18

- Fixed log visibility gaps in View Logs backend.
- Changes in `server.py`:
  - Added remote-EC2 docker container discovery via SSM + `docker ps` (not limited to worker compose services).
  - Expanded default EC2 log filter scope to include log DB VM name pattern (`nightmare-log-db*`).
  - Ensured central must-have docker log sources are always present in source list (`nightmare-coordinator-server`, `nightmare-postgres`, `nightmare-log-postgres`).
  - Enabled docker log reads for remote VM sources (`system=remote_vm`) using existing SSM log readers.
  - Updated `/api/coord/log-events` to fall back to live source parsing when structured log DB query returns zero rows, instead of returning empty immediately.
- Updated `deploy/docker-compose.central.yml` default `COORDINATOR_LOG_EC2_FILTER_VALUES` to include `nightmare-log-db*`.
- Why: operators were seeing empty/no-log behavior despite active fleet services and required visibility for coordinator + both DBs.
## 2026-04-18

- Added View Logs diagnostics subsystem.
- New API endpoint:
  - `GET /api/coord/log-source-diagnostics` (auth required)
  - Probes sources and returns per-source status (`ok/error`), line count, error text, and preview.
- Updated `templates/view_logs.html.j2`:
  - Added `Run Diagnostics` action.
  - Added diagnostics summary + table with per-source error visibility.
  - Added timeout-aware diagnostics status messaging.
- Log source coverage fixes:
  - Added remote EC2 docker discovery via SSM `docker ps` across matched EC2 instances (not just worker compose stack).
  - Included dedicated log DB VM pattern in default EC2 filter values.
  - Ensured central coordinator + central DB + log DB docker sources are always present in source list.
  - Allowed source reader to handle `system=remote_vm` docker sources.
  - `/api/coord/log-events` now falls back to live source reads when log DB query returns zero rows.
- Why: operators need immediate visibility into why a source is empty/failing and must always see coordinator + DB log sources.
## 2026-04-18

- Fixed bootstrap rerun failure on RPM-managed Python hosts (Amazon Linux):
  - `deploy/bootstrap-central-auto.sh` no longer attempts `pip --upgrade pip`.
  - Kept dependency install via pip but with `--disable-pip-version-check` and without self-uninstall path.
- Why: reruns were failing with `Cannot uninstall pip ... RECORD file not found` when pip came from rpm.
## 2026-04-18

- Hardened deploy script executability handling:
  - `deploy/bootstrap-central-auto.sh` now auto-applies `chmod +x` across `deploy/*.sh` at startup.
  - Added `ensure_executable()` guard used for `provision-log-db-aws.sh` and `provision-workers-aws.sh` so missing execute-bit no longer breaks reruns when file exists.
  - Added execute-bit self-heal in both full deploy wrappers (`deploy/full_deploy_command.sh`, `full_deploy_command.sh`) before invoking bootstrap.
- Why: EC2 reruns failed with `Missing executable .../provision-log-db-aws.sh` after checkouts/copies that dropped script mode bits.
## 2026-04-18

- Updated deploy privilege model in `deploy/bootstrap-central-auto.sh`:
  - Added `run_as_python_user()` so all Python/pip installs run as the invoking non-root user (`$SUDO_USER`) when script is started with sudo.
  - Kept docker/package-manager elevation behavior intact (`sudo` only where needed for docker/system operations).
  - Pip install path now uses user context + `--user` when running from sudo to avoid root-owned package installs and permission conflicts.
- Why: full deploy runs started with `sudo` were still executing pip in elevated context, causing failures and ownership issues.
## 2026-04-18

- Fixed deploy bootstrap dependency gap for AWS provisioning:
  - `deploy/bootstrap-central-auto.sh` now treats `aws` CLI as a required dependency in `install_deps_if_missing()`.
  - Added `awscli` package install for yum/dnf/apt flows.
- Why: full deploy path provisions worker/log DB EC2 resources and was failing with `Missing required command: aws` on central VM.
## 2026-04-18

- Fixed post-bootstrap target-registration privilege mismatch in full deploy wrappers:
  - `deploy/full_deploy_command.sh` and `full_deploy_command.sh` now run `register_targets.py` via `run_as_invoking_user`.
  - When invoked with sudo, this forces the Python registration step to run as `$SUDO_USER` instead of root.
- Why: `httpx` was installed in user site-packages, but wrapper executed `register_targets.py` as root and failed with `ModuleNotFoundError: No module named 'httpx'`.
## 2026-04-18

- Made full deploy flow idempotent/re-runnable for AWS fleet updates.
- `deploy/full_deploy_command.sh` now reconciles workers instead of always provisioning new ones:
  - Always updates/rebuilds central stack via `bootstrap-central-auto.sh` without DB reset.
  - Registers targets after coordinator readiness.
  - If no worker VMs exist (`tag:Name=nightmare-worker*`), provisions default worker count.
  - If workers exist, starts stopped workers if needed, then runs `client.py rollout` to rebuild/redeploy worker docker stacks with latest code.
- `full_deploy_command.sh` now delegates to `deploy/full_deploy_command.sh` to keep a single canonical implementation.
- Why: repeated deploy runs were creating drift/failures by re-provisioning every time; expected behavior is reconcile + preserve Postgres data unless explicitly reset.
## 2026-04-18

- Hardened central bootstrap DB credential recovery for reruns:
  - `deploy/bootstrap-central-auto.sh` now attempts to recover `POSTGRES_PASSWORD` from the existing `nightmare-postgres` container config when `.env` is missing the password.
  - Added `run_docker()` wrapper and switched existing-install detection to use docker access mode (direct vs sudo).
  - Existing-install failure message now explicitly notes container-recovery attempt.
- Why: full deploy reruns failed when Postgres data existed but `.env` lost `POSTGRES_PASSWORD`; rerunnable deploy should preserve DB access by recovering existing credentials when possible.
## 2026-04-18

- Fixed sudo-run deploy permission break during worker rollout (`Permission denied: deploy/.env`).
- `deploy/bootstrap-central-auto.sh` now restores ownership of generated files to invoking user (`$SUDO_USER`) after writes:
  - `deploy/.env`
  - `deploy/worker.env.generated`
  - `deploy/coordinator-host-env.sh`
- `deploy/provision-log-db-aws.sh` now restores invoking-user ownership when updating `.env` via `set_env_key`.
- Hardened env-file reads against permission errors:
  - `nightmare_shared/config.py::read_env_file` now returns `{}` on read exceptions.
  - `client.py::_read_env_file` now returns `{}` on read exceptions.
- Why: full deploy can run with sudo for docker/system actions, but post-bootstrap Python rollout executes as non-root user and must be able to read `deploy/.env`.
## 2026-04-18

- Fixed sudo deploy file-permission/ownership drift so non-root operator tools can read generated files.
- `deploy/bootstrap-central-auto.sh` now resolves invoking user identity and re-owns generated artifacts when launched via sudo:
  - `deploy/.env`, `deploy/worker.env.generated`, `deploy/coordinator-host-env.sh`, TLS cert/key, and appended `.bashrc` updates.
  - `.bashrc` update target now uses invoking user home directory instead of root home.
- `deploy/provision-log-db-aws.sh` now restores ownership of `.env` updates using invoking user + primary group (not username-assumed group).
- Why: sudo-run deploys created root-only files that broke non-root rollout/status commands and normal operator workflows.
## 2026-04-18

- Reduced log-viewer noise when coordinator runtime lacks docker CLI binaries.
- `server.py` updates:
  - `_compose_command_prefixes()` no longer injects fake fallback commands when binaries are missing.
  - view-log local docker source discovery now skips local docker sources if neither `docker` nor `docker-compose` is available.
  - compose status/log helpers now return explicit `"docker compose commands are not available in this runtime"` when unavailable.
  - mandatory local docker source injection (`nightmare-coordinator-server`, `nightmare-postgres`, `nightmare-log-postgres`) is now gated on actual local docker/compose command availability.
- Why: prevent repeated `[Errno 2] No such file or directory: 'docker'` synthetic error events in View Logs when running inside minimal app containers.

## 2026-04-18

- Removed noisy unauthorized UI-preference calls on pages without tokens.
- `templates/_grid_controls.html.j2` now calls `/api/coord/ui-preferences` only when an Authorization token is available; otherwise it uses localStorage-only preference load/save.
- Why: dashboard and other tokenless pages were emitting browser-console `401 Unauthorized` for preference fetches.

## 2026-04-18

- Hardened central bootstrap token reuse to prevent worker auth drift on reruns.
- `deploy/bootstrap-central-auto.sh` now attempts to recover `COORDINATOR_API_TOKEN` from the running `nightmare-coordinator-server` container when `.env` is missing/incomplete (and not `--force`).
- Why: this prevents unintended token regeneration that causes workers to loop on `401 Unauthorized` for claim/poll endpoints.

## 2026-04-18

- Standardized website table time rendering toward fixed EST (`UTC-5`) `HH:MM:SS` display for column data.
- `templates/crawl_progress.html.j2`:
  - changed `Last Activity` column label to `Last Activity (EST)`;
  - added deterministic client formatter to render `last_activity_at_utc` as `HH:MM:SS` in fixed UTC-5.
- `templates/view_logs.html.j2` + `server.py`:
  - added diagnostics table `Time (EST)` column;
  - diagnostics rows now include `checked_at_est_time` generated server-side via shared EST time formatter.
- `server.py`:
  - added `_format_est_time(dt)` helper to keep EST time-only formatting consistent with no fractional seconds.
- Why: enforce a single operator-friendly time format in table columns (`HH:MM:SS`, EST/UTC-5) and remove mixed ISO/date-time outputs in grids.

## 2026-04-18

- Prevented unwanted extra log-DB VM provisioning on reruns when infra already exists.
- `deploy/bootstrap-central-auto.sh` now recovers missing `LOG_DATABASE_URL` from existing `nightmare-coordinator-server` container env before deciding to provision log DB.
- `deploy/provision-log-db-aws.sh` now:
  - recovers `LOG_DATABASE_URL` from existing coordinator container env and writes it to `.env` when missing;
  - detects existing log DB instances by tag (`${INSTANCE_NAME_PREFIX}*`) and refuses to provision duplicates when URL is missing.
- Why: reruns were trying to create another VM and failing with `VcpuLimitExceeded` even though fleet was already up.
## 2026-04-18

- Fixed worker 401 unauthorized loops after redeploy by syncing coordinator credentials during rollout.
- `client.py` `_run_ssm_rollout(...)` now accepts and propagates coordinator connection settings:
  - `coordinator_base_url`
  - `api_token`
  - `coordinator_insecure_tls`
- Rollout SSM script now rewrites worker `deploy/.env` with current coordinator URL/token/TLS mode before `docker compose up -d --build`.
- `deploy/full_deploy_command.sh` now invokes `client.py rollout` with explicit coordinator URL/token and `--insecure-tls` when configured.
- Added regression test `test_client_rollout_updates_worker_env_before_compose` to validate worker `.env` rewrite is included in SSM rollout payload.
- Validation: `python -m pytest -q tests/test_client_and_cli_unit.py` -> 12 passed.
- Why: workers kept stale tokens across central token changes and repeatedly received `401 unauthorized` on coordinator endpoints.
## 2026-04-18

- Fixed coordinator/local DB log-source failures when `docker` CLI is unavailable in server runtime (`[Errno 2] No such file or directory: 'docker'`).
- `server.py` local docker log readers now fallback to compose-service logs:
  - Added container->compose service candidate mapping for core services (`nightmare-coordinator-server`, `nightmare-postgres`, `nightmare-log-postgres`).
  - Added compose log execution helper that tries both `docker compose` and `docker-compose`, with/without `--env-file`.
  - Log read paths (`_read_docker_log_tail`, `_read_docker_log_full`) now try `docker logs` first, then compose fallback candidates.
- Expanded compose spec discovery to include `deploy/docker-compose.log-store.yml` so log-store service fallback resolves.
- Validation: `python -m pytest -q tests/test_client_and_cli_unit.py tests/test_reporting_and_store_helpers.py` -> 38 passed.
- Why: View Logs entries for coordinator + DB containers should remain readable even when only compose client is present.
