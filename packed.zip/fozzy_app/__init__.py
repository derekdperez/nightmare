"""Fozzy modular helpers."""

