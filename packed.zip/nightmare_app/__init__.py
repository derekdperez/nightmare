"""Nightmare crawler app modules."""

