"""Shared HTML reporting helpers."""
